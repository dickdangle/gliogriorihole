# The Fuse

Log of the first post and its effect.