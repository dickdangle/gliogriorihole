# Byte Origin

How Byte.txt came into being. A POV relic.