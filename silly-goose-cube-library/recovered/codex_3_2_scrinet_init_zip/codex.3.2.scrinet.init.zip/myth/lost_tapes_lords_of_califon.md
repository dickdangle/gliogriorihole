# Lords of Califon: Lost Tapes

Flash said we weren't ready. Jay Skippi had just finished the code dump when the lights went out.

A single tape remained. Brownie etched a squid on the label: SQD-LOC-7777777777-LOST.

They thought it was just lore. But the VM inside still runs.