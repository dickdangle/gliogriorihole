# Rituals

Placeholder for executable Codex spells.