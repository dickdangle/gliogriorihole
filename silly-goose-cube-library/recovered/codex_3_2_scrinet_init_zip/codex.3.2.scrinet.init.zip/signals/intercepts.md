# Intercepts

Evidence of field resonance.